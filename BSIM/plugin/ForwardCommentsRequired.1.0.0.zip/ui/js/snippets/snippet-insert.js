    function clearButton(){
        if ( $( "#forwardCommentBox" ).length > 0 )  
        {   	
         
            jQuery("#forwardCommentBox").css("border-color", "red");
       
          
            if ($('#forwardCommentBox').val().trim()!= '')
            	{
            	enableButton();
            	}
            else
            	{
            	disableButton();
            	}
         }
            else
            	{
            	disableButton();
            	}
           	
    }
    function disableButton()
    {
    	jQuery(":contains('Forward')").attr("disabled", true);
    }
    function enableButton()
    {
    	jQuery(":contains('Forward')").attr("disabled", false);
    }
jQuery(document).ready(function(){
	setInterval(function(){ clearButton(); }, 10);
	
}); 