/**
 @author Abhishek Chowdhury
 @email abhishek.20c@gmail.com
 **/
function checkComment() {
	if ($("*").hasClass("btn btn-sm m-l-xs btn-white")) {

		jQuery("[ng-click='reviewCtrl.showCommentDialog(requestedItem)']").css(
				"border-color", "red");
		jQuery("[ng-click='reviewCtrl.showCommentDialog(removedItem)']").css(
				"border-color", "red");

		disableButton();

	} else {

		jQuery("[ng-click='reviewCtrl.showCommentDialog(requestedItem)']").css(
				"border-color", "white");
		jQuery("[ng-click='reviewCtrl.showCommentDialog(removedItem)']").css(
				"border-color", "white");
		enableButton();
	}

}
function disableButton() {

	jQuery("#submitBtn").attr("disabled", true);
}
function enableButton() {

	jQuery("#submitBtn").attr("disabled", false);
}
jQuery(document).ready(function() {
	setInterval(function() {
		checkComment();
	}, 10);

});